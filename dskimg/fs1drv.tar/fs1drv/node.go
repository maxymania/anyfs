/*
 * MIT License
 * 
 * Copyright (c) 2017 Simon Schmidt
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package fs1drv

import "github.com/hanwen/go-fuse/fuse"
import "github.com/hanwen/go-fuse/fuse/nodefs"

import "github.com/maxymania/anyfs/dskimg/fs1"
import "github.com/maxymania/anyfs/dskimg/ods"

import "github.com/maxymania/anyfs/security"

import "github.com/maxymania/anyfs/debug"

func opennode(fs *fs1.FileSystem, ent ods.DirectoryEntryValue) (bool,nodefs.Node,fuse.Status) {
	file := fs.GetFile(ent.File_MFT,ent.File_IDX)
	mfte,e := file.GetMFTE()
	if e!=nil { return false,nil,fuse.EIO }
	if mfte.Cookie!=ent.Cookie { return false,nil,fuse.EINVAL } /* XXX Cookie error: delete the entry. */
	switch mfte.FileType {
	case ods.FT_FILE:{
		n := &FileNode{nodefs.NewDefaultNode(),&fs1.AutoGrowingFile{file}}
		return false,n,fuse.OK
		}
	case ods.FT_DIR:{
		d,e := file.AsDirectory()
		if e!=nil { return false,nil,fuse.EIO }
		dn := new(DirNode)
		dn.Node = nodefs.NewDefaultNode()
		dn.Backing = file
		dn.Dir = d
		return true,dn,fuse.OK
		}
	case ods.FT_FIFO:{
		mm := new(ReprNode)
		mm.Node = nodefs.NewDefaultNode()
		mm.Attr.Mode = fuse.S_IFIFO | 0666
		mm.Backing = file
		return true,mm,fuse.OK
		}
	}
	return false,nil,fuse.EIO
}

func get_user_sids( context *fuse.Context) []security.SID {
	sids := make([]security.SID,0,4)
	sids = append(sids,security.SIDC_ANY_USER)
	if context!=nil {
		if context.Uid==0 || context.Gid==0 {
			sids = append(sids,security.SIDC_ROOT)
		}
		sids = append(sids,security.UidSID(context.Uid),security.GidSID(context.Gid))
		debug.Println(sids)
	}
	return sids
}

func modeToPrivileges(mode uint32) security.Privileges {
	r := security.PrNone
	if (mode&0444)!=0 { r|=security.PrRead }
	if (mode&0222)!=0 { r|=security.PrWrite }
	if (mode&0111)!=0 { r|=security.PrExecute }
	return r
}

func get_file_acv(f *fs1.File, context *fuse.Context) (security.AccessControlVector,error) {
	mdf,e := f.GetMDF()
	if e==fs1.Enotfound { return security.PrFullControl.AllowVector(),nil }
	if e!=nil { return security.AccessControlVector(0),e }
	acv := mdf.Memory.ACL.GetRights(get_user_sids(context))
	debug.Println(acv)
	return acv,nil
}

func get_create_default_sids( context *fuse.Context) []security.SID {
	sids := make([]security.SID,0,2)
	if context!=nil {
		sids = append(sids,security.UidSID(context.Uid),security.GidSID(context.Gid))
	}
	sids = append(sids,security.SIDC_ANY_USER)
	return sids
}

type ReprNode struct{
	nodefs.Node
	Attr fuse.Attr
	Backing *fs1.File
}

func (m *ReprNode) GetAttr(out *fuse.Attr, file nodefs.File, context *fuse.Context) (fuse.Status) {
	*out = m.Attr
	return fuse.OK
}

/* Mode-Nodes must be kept in memory in order to reserve their INODE number. */
func (m *ReprNode) Deletable() bool { return false }


type ModeNode struct{
	nodefs.Node
	Attr fuse.Attr
}

func (m *ModeNode) GetAttr(out *fuse.Attr, file nodefs.File, context *fuse.Context) (fuse.Status) {
	*out = m.Attr
	return fuse.OK
}

/* Mode-Nodes must be kept in memory in order to reserve their INODE number. */
func (m *ModeNode) Deletable() bool { return false }


